package com.accenture.sandeep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SandeepApplication {

	public static void main(String[] args) {
		SpringApplication.run(SandeepApplication.class, args);
	}

}
