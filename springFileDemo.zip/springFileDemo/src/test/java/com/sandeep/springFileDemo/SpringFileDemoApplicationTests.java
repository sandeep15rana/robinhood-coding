package com.sandeep.springFileDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFileDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
